
public class PruebaNif {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char [] val1 = {'0','3','4','4','5','0','8','5','Z'};
		String val2 = "12345678B";
		NifStr nif1 = new NifStr(val1);
		NifStr nif2 = new NifStr(val2);
		Nif nif3 = new Nif(val1);
		Nif nif4 = new Nif(val2);
		
		NifStr [] colNifs1 = {nif1,nif2}; // pero no nif3 o nif4
		System.out.println("\n\n------------ TODOS NifStr");
		for (int i=0; i<colNifs1.length;i++)
		{
			System.out.println(colNifs1[i]);
		}
		
		System.out.println("\n\\n------------  TODOS Nif");
		Nif [] colNifs2 = {nif3,nif4}; // pero no nif1 o nif2
		for (int i=0; i<colNifs2.length;i++)
		{
			System.out.println(colNifs2[i]);
		}
		INif nif5 = new NifStr(val1);
		INif nif6 = new NifStr(val1);
		
		
		INif [] colNifs3 = {nif2,nif6, nif4,nif5,nif3, nif1};  // todas valen
		
		System.out.println("\n\n------------ MEZCLA ----");

		for (int i=0; i<colNifs3.length;i++)
		{
			System.out.println(colNifs3[i]);
		}
	}

}
