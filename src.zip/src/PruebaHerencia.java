
public class PruebaHerencia {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Vehiculo v1 = new Vehiculo ("moto",2);
        Vehiculo v2 = new Vehiculo ("coche",4);
        Automovil coche = new Automovil();
        Moto moto = new Moto();
        
		System.out.println(v1);
		System.out.println(v2);
		System.out.println(coche);
		System.out.println(moto);

  //      System.out.println(v1.manosLibres());
  //      System.out.println(v2.casco());
        System.out.println(coche.manosLibres());
        System.out.println(moto.casco());

		
		
	}

}
