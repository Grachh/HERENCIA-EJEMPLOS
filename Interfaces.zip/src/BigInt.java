
public interface BigInt {

	public boolean esPar();
	public int iesimo (int i);
	public BigInt suma (BigInt x);
}
