
public class BigIntStr implements BigIntPlus {

	private String num;
	
	public BigIntStr() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BigIntStr(String num) {
		super();
		this.num = num;
	}

	public static BigIntPlus create(String num)
	{
		return new BigIntStr(num);
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((num == null) ? 0 : num.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BigIntStr other = (BigIntStr) obj;
		if (num == null) {
			if (other.num != null)
				return false;
		} else if (!num.equals(other.num))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "BigIntStr [num=" + num + "]";
	}

	@Override
	public boolean esPar() {
		// TODO Auto-generated method stub
		char ultimo = num.charAt(num.length()-1);
		return LibNif.aDigito(ultimo) % 2 == 0;
	}

	@Override
	public int iesimo(int i) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public BigInt suma(BigInt x) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int longitud() {
		// TODO Auto-generated method stub
		return num.length();
	}

}
