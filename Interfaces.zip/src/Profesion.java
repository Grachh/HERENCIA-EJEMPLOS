
public interface Profesion {

	public int horasDedicadas();
	public boolean porCuentaAjena();
	public boolean funcionario();
	public int nivelRiesgo();
	public double salario();
}
