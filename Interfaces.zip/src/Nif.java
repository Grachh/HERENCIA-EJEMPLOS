
public class Nif implements INif {

	private char letra;
	private int num;
	
	

	public Nif() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Nif(char letra, char num) {

		this.letra = letra;
		this.num = num;
	}
	
	public Nif(char[] nif) {

		this.letra = nif[8];
		this.num = LibNif.aNum(nif);
	}
	public Nif(String nif) {
		this(nif.toCharArray());
	}

	@Override
	public char letra() {
		// TODO Auto-generated method stub
		return letra;
	}

	@Override
	public int numero() {
		// TODO Auto-generated method stub
		return num;
	}

	@Override
	public void setNif(String s) {
		// TODO Auto-generated method stub
		char [] nif = s.toCharArray();
		letra = nif[8];
		num = LibNif.aNum(nif);
	}

	@Override
	public String toString() {
		return "Nif [letra=" + letra + ", num=" + num + "]";
	}

}
