
public interface MedioSexual extends Profesion, Aficion{

}
