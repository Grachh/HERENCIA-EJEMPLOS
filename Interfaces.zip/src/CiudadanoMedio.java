
public class CiudadanoMedio implements MedioSexual {

	private Profesion prof;
	private Aficion aficion;
	
	public CiudadanoMedio() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CiudadanoMedio(Profesion prof, Aficion aficion) {
		super();
		this.prof = prof;
		this.aficion = aficion;
	}

	@Override
	public String toString() {
		return "CiudadanoMedio [prof=" + prof + ", aficion=" + aficion + "]";
	}

	@Override
	public int horasDedicadas() {
		// TODO Auto-generated method stub
		return aficion.horasALaSemana();
	}

	@Override
	public boolean porCuentaAjena() {
		// TODO Auto-generated method stub
		return prof.porCuentaAjena();
	}

	@Override
	public boolean funcionario() {
		// TODO Auto-generated method stub
		return prof.funcionario();
	}

	public Aficion getAficion() {
		return aficion;
	}

	public void setAficion(Aficion aficion) {
		this.aficion = aficion;
	}

	@Override
	public int nivelRiesgo() {
		// TODO Auto-generated method stub
		return prof.nivelRiesgo();
	}

	@Override
	public double salario() {
		// TODO Auto-generated method stub
		return prof.salario();
	}

	@Override
	public String actividad() {
		// TODO Auto-generated method stub
		return aficion.actividad();
	}

	@Override
	public int horasALaSemana() {
		// TODO Auto-generated method stub
		return aficion.horasALaSemana();
	}

}
