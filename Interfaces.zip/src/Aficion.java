
public interface Aficion {
	public String actividad();
	public int horasALaSemana();
}
