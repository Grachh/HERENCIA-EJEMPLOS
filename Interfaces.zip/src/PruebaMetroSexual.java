
public class PruebaMetroSexual {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Metrosexual metro; 
		MedioSexual medio;
		
		Aficion cocinar = new Cocinar ("cocina creativa",3,2,4);
		Aficion yoga = new Yoga ("Sensui",4);
		
		System.out.println (cocinar);
		System.out.println (yoga);
		
		Aficion[] aficiones = {yoga,cocinar};
		
		Profesion profe = new Funcionario ("UPM",20,550.5,3);
		Profesion glovo = new Glovo (200.50,50);
		System.out.println (profe);
		System.out.println (glovo);
		
		
		MedioSexual ciudadano1 = new CiudadanoMedio (profe,yoga);	
		System.out.println (ciudadano1);
	  
	}

}
