
public class Funcionario implements Profesion {

	private String administracion;
	private int horasDedicadas;
	private double salario;
	private int nivelRiesgo;
	
	
	public Funcionario() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Funcionario(String administracion, 
						int horasDedicadas, 
						double salario, 
						int nivelRiesgo) {
		super();
		this.administracion = administracion;
		this.horasDedicadas = horasDedicadas;
		this.salario = salario;
		this.nivelRiesgo = nivelRiesgo;
	}

	@Override
	public String toString() {
		return "Funcionario [administracion=" + administracion + ", horasDedicadas=" + horasDedicadas + ", salario="
				+ salario + ", nivelRiesgo=" + nivelRiesgo + "]";
	}

	public String getAdministracion() {
		return administracion;
	}

	public void setAdministracion(String administracion) {
		this.administracion = administracion;
	}

	@Override
	public int horasDedicadas() {
		// TODO Auto-generated method stub
		return horasDedicadas;
	}

	@Override
	public boolean porCuentaAjena() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean funcionario() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public int nivelRiesgo() {
		// TODO Auto-generated method stub
		return nivelRiesgo;
	}

	@Override
	public double salario() {
		// TODO Auto-generated method stub
		return salario;
	}

}
