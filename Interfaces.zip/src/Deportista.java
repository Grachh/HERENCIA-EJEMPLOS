
public interface Deportista {

	public int horasPractica();
	public boolean esDeRiesgo();
	public boolean deEquipo();
	public boolean inDoor();
	public String nombreDeporte();
}
