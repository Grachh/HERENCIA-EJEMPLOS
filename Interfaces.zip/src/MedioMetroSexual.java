
public interface MedioMetroSexual extends Profesion, Aficion {

}
