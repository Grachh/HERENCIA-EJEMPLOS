
public class Moto extends Vehiculo {

	private boolean casco;
	public Moto() {
		super("moto", 2);
		// TODO Auto-generated constructor stub
	}

	public Moto(String tipo, int ruedas) {
		super(tipo, ruedas);
		// TODO Auto-generated constructor stub
	}
	
	public boolean casco() {
		return casco;
	}
	
	@Override
	public String toString() {
		return "Moto []" + "casco:" + casco();
	}
}
