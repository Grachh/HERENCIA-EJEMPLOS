
public class Automovil extends Vehiculo {

	private int cilindrada;
	
	public Automovil() {
		super("automovil",4);
		// TODO Auto-generated constructor stub
	}

	public Automovil(String tipo, int ruedas) {
		super(tipo, ruedas);
		// TODO Auto-generated constructor stub
	}
	
	public boolean manosLibres()
	{
		return true;
	}

	@Override
	public String toString() {
		return "Automovil []" + "ruedas:" + super.getRuedas() + "cilindrada:" + cilindrada;
	}
	
	

}
