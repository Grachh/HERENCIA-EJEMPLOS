
public class Yoga implements Aficion {

	private String actividad;
	private int horasSemana;
	@Override
	
	
	public String actividad() {
		// TODO Auto-generated method stub
		return actividad;
	}

	public Yoga(String actividad, int horasSemana) {
		super();
		this.actividad = actividad;
		this.horasSemana = horasSemana;
	}

	public Yoga() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public int horasALaSemana() {
		// TODO Auto-generated method stub
		return horasSemana;
	}

	@Override
	public String toString() {
		return "Yoga [actividad=" + actividad + ", horasSemana=" + horasSemana + "]";
	}

}
