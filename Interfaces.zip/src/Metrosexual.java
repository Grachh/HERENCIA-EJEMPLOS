
public interface Metrosexual extends Aficion, Deportista, Profesion {

}
