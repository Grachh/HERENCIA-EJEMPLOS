import java.util.Arrays;

public class NifStr implements INif {

	private char[] nif = new char[9];
	
	
	public NifStr() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NifStr(char[] nif) {
		super();
		this.nif = nif;
	}
	public NifStr(String nif) {
		super();
		this.nif = nif.toCharArray();
	}

	@Override
	public char letra() {
		// TODO Auto-generated method stub
		return nif[8];
	}

	@Override
	public int numero() {
		// TODO Auto-generated method stub
		return LibNif.aNum(nif);
	}
	
	@Override
	public void setNif(String s) {
		nif = s.toCharArray();
		
	}

	@Override
	public String toString() {
		return "NifStr [nif=" + Arrays.toString(nif) + "]";
	}
		

}
