
public interface BigIntPlus extends BigInt {

	public int longitud();
}
