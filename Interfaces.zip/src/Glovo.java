
public class Glovo implements Profesion {

	private double salario;
	private int horasDedicadas;
	
	
	
	public Glovo(double salario, int horasDedicadas) {
		super();
		this.salario = salario;
		this.horasDedicadas = horasDedicadas;
	}

	public Glovo() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Glovo [salario=" + salario + ", horasDedicadas=" + horasDedicadas + "]";
	}

	@Override
	public int horasDedicadas() {
		// TODO Auto-generated method stub
		return horasDedicadas;
	}

	@Override
	public boolean porCuentaAjena() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean funcionario() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int nivelRiesgo() {
		// TODO Auto-generated method stub
		return 10;
	}

	@Override
	public double salario() {
		// TODO Auto-generated method stub
		return salario;
	}

}
