
public class PruebaHerencia {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Vehiculo v1 = new Vehiculo ("moto",2);
        Vehiculo v2 = new Vehiculo ("coche",4);
        Vehiculo v3 = new Automovil("coche,",3);
        
        
        Automovil coche = new Automovil();
        
        
        Moto moto = new Moto();
        if(v1 instanceof Vehiculo){
			System.out.println("v1 es un vehiculo.");
		}
        if(v1 instanceof Automovil){
 			System.out.println("v1 es un automovil.");
 		}
        if(v3 instanceof Vehiculo){
			System.out.println("v3 es un vehiculo.");
		}
        if(v3 instanceof Automovil){
 			System.out.println("v3 es un automovil.");
 		}
        
        
		System.out.println(v1);
		System.out.println(v2);
		System.out.println(coche);
		System.out.println(moto);

  //      System.out.println(v1.manosLibres());
  //      System.out.println(v2.casco());
        System.out.println(coche.manosLibres());
        System.out.println(moto.casco());

		
		
	}

}
