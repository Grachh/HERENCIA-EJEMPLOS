
public class Cocinar implements Aficion {

	private String actividad;
	private int horasALaSemana;
	private int suscripciones;
	private int cursos;
	
	public Cocinar() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cocinar(String actividad, int horasALaSemana, int suscripciones, int cursos) {
		super();
		this.actividad = actividad;
		this.horasALaSemana = horasALaSemana;
		this.suscripciones = suscripciones;
		this.cursos = cursos;
	}

	@Override
	public String toString() {
		return "Cocinar [actividad=" + actividad + ", horasALaSemana=" + horasALaSemana + ", suscripciones="
				+ suscripciones + ", cursos=" + cursos + "]";
	}

	public String getActividad() {
		return actividad;
	}

	public void setActividad(String actividad) {
		this.actividad = actividad;
	}

	public int getHorasALaSemana() {
		return horasALaSemana;
	}

	public void setHorasALaSemana(int horasALaSemana) {
		this.horasALaSemana = horasALaSemana;
	}

	public int getSuscripciones() {
		return suscripciones;
	}

	public void setSuscripciones(int suscripciones) {
		this.suscripciones = suscripciones;
	}

	public int getCursos() {
		return cursos;
	}

	public void setCursos(int cursos) {
		this.cursos = cursos;
	}

	@Override
	public String actividad() {
		// TODO Auto-generated method stub
		return actividad;
	}

	@Override
	public int horasALaSemana() {
		// TODO Auto-generated method stub
		return horasALaSemana;
	}

}
