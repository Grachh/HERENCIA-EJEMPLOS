
public class BigIntProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BigInt b1 = BigIntStr.create("1223878239789273847238974928374892374821");
		int [] nums = {1,2,3,4,5,2,2,4,2,3,1,3,5,5,5,5,5,4};
		BigInt b2 = new BigIntArray (nums);
		
		BigIntPlus b3 = new BigIntStr("1223878239789273847238974928374892374821");
		BigIntPlus b4 = new BigIntArray (nums);
		
		
		
		BigInt [] col = {b1,b2,b2,b1};
	
		
		BigIntPlus [] col2 = {b3,b4};
		
		
		System.out.println (b1.esPar());
		System.out.println (b2.esPar());
		for (int i=0; i < col.length; i++)
			System.out.println (col[i].esPar());
		System.out.println("\n\n");
		for (int i=0; i < col.length; i++)
			System.out.println (col[i]);
	}

}
