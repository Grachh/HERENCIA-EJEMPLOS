
public class LibNif {
	// METODOS AUXILIARES

	public static boolean esLetraMayuscula (char caracter){
		return 'A' <= caracter && caracter <= 'Z';
	}
	public static boolean esDigito (char caracter){
		return '0' <= caracter && caracter <= '9';
	}

	public static int aDigito (char c)
	{
		return c - '0';
	}
	
	// PROBLEMA DE TIPO MAP
	public static int[] sacarDigitos (char []nif)
	{
		int[] solucion = new int[nif.length-1];
		
		for (int i=0; i<solucion.length; i++)
			solucion[i] = aDigito(nif[i]);
		
		return solucion;
	}
	
	public static int aNumero (int [] col)
	{
		int suma = 0;
		for (int i=0; i<col.length; i++)
		{
			suma += col[i]*Math.pow(10,col.length-i-1);
		}
		return suma;
	}
	
	public static int aNum (char [] nif)
	{
		return aNumero(sacarDigitos(nif));
	}

}
