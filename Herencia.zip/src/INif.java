
public interface INif {

	public char letra();
	public int numero();
	public void setNif (String s);
}
