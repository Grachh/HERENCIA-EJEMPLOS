import java.util.Arrays;

public class BigIntArray implements BigIntPlus{

	private int[] num;
	
	
	
	public BigIntArray() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BigIntArray(int[] num) {
		super();
		this.num = num;
	}

	@Override
	public String toString() {
		return "BigIntArray [num=" + Arrays.toString(num) + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(num);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BigIntArray other = (BigIntArray) obj;
		if (!Arrays.equals(num, other.num))
			return false;
		return true;
	}

	@Override
	public boolean esPar() {
		// TODO Auto-generated method stub
		return num[num.length-1] % 2 == 0;
	}

	@Override
	public int iesimo(int i) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public BigInt suma(BigInt x) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int longitud() {
		// TODO Auto-generated method stub
		return num.length;
	}

}
